const generateRandomId = () => {
  const randomNumber = Math.floor(Math.random() * 100)

  return randomNumber
}

export default generateRandomId
