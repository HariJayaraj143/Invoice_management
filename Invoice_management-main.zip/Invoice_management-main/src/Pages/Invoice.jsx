import React from 'react'
import InvoiceForm from '../components/InvoiceForm'

const Invoice = () => {
  return <InvoiceForm />
}

export default Invoice
